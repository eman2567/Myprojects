#include <iostream>
#include "SimpleGraph.h"
#include "SimpleGraph.cpp"
#include "SimpleNode.h"
#include "SimpleNode.cpp"
#include "AttributedNode2.h"
#include "AttributedNode2.cpp"
#include "AttributedGraph2.h"
#include "AttributedGraph2.cpp"
#include "AttributedWeightedGraph.cpp"
#include "AttributedWeightedGraph.h"
using namespace std;
int main() {
    AttributedWeightedGraph graph(3);

    graph.appendAttributes();

    graph.appendWeight(0, 1, 52);
    graph.appendWeight(1, 2, 200);

    graph.printGraphData();

    return 0;
}

