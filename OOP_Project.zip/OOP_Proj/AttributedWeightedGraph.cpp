#include <iostream>
#include "AttributedWeightedGraph.h"
//#include "AttributedGraph1.cpp"


AttributedWeightedGraph::AttributedWeightedGraph(int n) : AttributedGraph1() {
    weights = new int*[n];
    for (int i = 0; i < n; i++) {
        weights[i] = new int[n];
        for (int j = 0; j < n; j++) {
            weights[i][j] = 0;
        }
    }
    std::cout << "AttributedWeightedGraph object created." << std::endl;
}

AttributedWeightedGraph::~AttributedWeightedGraph() {
    for (int i = 0; i < numNodes; i++) {
        delete[] weights[i];
    }
    delete[] weights;
    std::cout << "AttributedWeightedGraph object destroyed." << std::endl;
}

void AttributedWeightedGraph::appendWeight(int nodeId1, int nodeId2,
int weight) {
    weights[nodeId1][nodeId2] = weight;
    weights[nodeId2][nodeId1] = weight;
}